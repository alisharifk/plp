package com.cg.dao;

import java.util.List;

import com.cg.beans.Accounts;
import com.cg.beans.Policy;
import com.cg.beans.PolicyDetails;
import com.cg.beans.ReportGeneration;
import com.cg.beans.UserRole;
import com.cg.exceptions.InsuranceException;

public interface InsuranceService {

	String validUser(UserRole role) throws InsuranceException;

	int createAccount(Accounts accounts) throws InsuranceException;

	boolean validFields(Accounts accounts) throws InsuranceException;

	boolean getUserName(String userName) throws InsuranceException;

	boolean checkUserName(String userName) throws InsuranceException;

	boolean checkPassword(String password) throws InsuranceException;

	boolean checkUserRole(String userRole) throws InsuranceException;

	int addProfile(UserRole role) throws InsuranceException;

	int createPolicy(int accountNumber) throws InsuranceException;

	boolean validAccountNumber(int accountNumber) throws InsuranceException;

	boolean existAccount(int accountNumber) throws InsuranceException;

	String getBuisnessSegment(int accountNumber) throws InsuranceException;

	String getBuisnessSegmentId(String businessSegment) throws InsuranceException;

	List<String> getQuestions(String buisnessSegId) throws InsuranceException;

	List<String> getAnswer(String string) throws InsuranceException;

	int getWeightage(String string, String string2) throws InsuranceException;

	int insertPolicy(Policy policy)throws InsuranceException;

	String getQuesId(String string) throws InsuranceException;

	List<String> getQuestionId(String buisnessSegId) throws InsuranceException;

	void insertPolicyDetails(PolicyDetails policyDetails) throws InsuranceException;

	List<Policy> viewPolicyDetails() throws InsuranceException;

	List<ReportGeneration> generateReport(int accountNumber1) throws InsuranceException;

	Policy getPolicy(String userName) throws InsuranceException;



}
