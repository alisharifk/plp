package com.cg.classes;

import java.util.List;

import com.cg.beans.ReportGeneration;
import com.cg.dao.InsuranceService;
import com.cg.dao.InsuranceServiceImpl;
import com.cg.exceptions.InsuranceException;

public class GenerateReport {

	InsuranceService insuranceService= new InsuranceServiceImpl();

	public List<ReportGeneration> generateReport(int accountNumber1) throws InsuranceException{
		return insuranceService.generateReport(accountNumber1);
		
	}
}
