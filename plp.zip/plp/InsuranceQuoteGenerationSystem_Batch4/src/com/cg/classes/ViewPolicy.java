package com.cg.classes;

import java.util.List;

import com.cg.beans.Policy;
import com.cg.dao.InsuranceService;
import com.cg.dao.InsuranceServiceImpl;
import com.cg.exceptions.InsuranceException;

public class ViewPolicy {

	InsuranceService service=new InsuranceServiceImpl();
	public List<Policy> viewPolicyDetails() throws InsuranceException{
		
		List<Policy> list=null;
		try {
			list=service.viewPolicyDetails();
		} catch (InsuranceException e) {
			System.err.println(e.getMessage());
		}
		
		return list;
		
	}
	public Policy getPolicy(String userName)throws InsuranceException {
		
		return service.getPolicy(userName);
	}

}
